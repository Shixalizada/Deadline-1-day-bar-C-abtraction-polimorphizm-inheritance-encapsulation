﻿using System;

namespace ProductOrderCustomerApp
{
    public class Menu
    {
        public static void Show()
        {
            Console.WriteLine("Welcome");
            Console.WriteLine("1. Add Product");
            Console.WriteLine("2. All Products");
            Console.WriteLine("3. Get Product by ID");
            Console.WriteLine("4. Remove Product");
            Console.WriteLine("5. Get Order by ID");
            Console.WriteLine("6. All Orders");
            Console.WriteLine("7. Remove Order");
            Console.WriteLine("8. Add Customer");
            Console.WriteLine("9. Get Customer by ID");
            Console.WriteLine("10. All Customers");
            Console.WriteLine("0. Exit");
        }
    }
}