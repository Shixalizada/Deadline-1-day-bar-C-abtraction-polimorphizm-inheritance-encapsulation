﻿using System;

namespace ProductOrderCustomerApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var productService = new ProductService();
            var customerService = new CustomerService();
            var orderService = new OrderService();

            while (true)
            {
                Menu.Show();
                Console.Write("Select option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Product name: ");
                        break;

                    case "2":
                        foreach (var p in productService.GetAll())
                            Console.WriteLine($"ID: {p.Id}, Name: {p.Name}, Price: {p.Price}");
                        break;

                    case "3":
                        Console.Write("Enter Product ID: ");
                        break;


                    case "4":
                        Console.Write("Enter Product ID to remove: ");
 
                        break;

                    case "5":
                        Console.Write("Enter Order ID: ");
                        break;

                    case "6":
                        foreach (var o in orderService.GetAll())
                            Console.WriteLine($"Order ID: {o.Id}, Product ID: {o.ProductId}, Customer ID: {o.CustomerId}");
                        break;

                    case "7":
                        Console.Write("Enter Order ID to remove: ");
                        break;

                    case "8":
                        Console.Write("Customer name: ");
                        break;

                    case "9":
                        Console.Write("Enter Customer ID: ");
                        break;

                    case "10":
                        foreach (var c in customerService.GetAll())
                            Console.WriteLine($"ID: {c.Id}, Name: {c.Name}");
                        break;

                    case "0":
                        return;

                    default:
                        Console.WriteLine("Invalid option.");
                        break;
                }

                Console.WriteLine();
            }
        }
    }
}