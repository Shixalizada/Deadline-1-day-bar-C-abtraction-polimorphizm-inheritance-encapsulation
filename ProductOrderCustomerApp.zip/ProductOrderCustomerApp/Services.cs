﻿using System.Collections.Generic;
using System.Linq;

namespace ProductOrderCustomerApp
{
    public class ProductService
    {
        private List<Product> products = new();

        public void AddProduct(Product product) => products.Add(product);
        public List<Product> GetAll() => products;
        public Product GetById(int id) => products.FirstOrDefault(p => p.Id == id);
        public void Remove(int id) => products.RemoveAll(p => p.Id == id);
    }

    public class CustomerService
    {
        private List<Customer> customers = new();

        public void AddCustomer(Customer customer) => customers.Add(customer);
        public Customer GetById(int id) => customers.FirstOrDefault(c => c.Id == id);
        public List<Customer> GetAll() => customers;
    }

    public class OrderService
    {
        private List<Order> orders = new();

        public void AddOrder(Order order) => orders.Add(order);
        public Order GetById(int id) => orders.FirstOrDefault(o => o.Id == id);
        public List<Order> GetAll() => orders;
        public void Remove(int id) => orders.RemoveAll(o => o.Id == id);
    }
}
